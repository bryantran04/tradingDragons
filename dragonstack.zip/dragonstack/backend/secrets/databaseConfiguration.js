module.exports = {
    user: 'node_user',
    host: 'localhost',
    database: 'dragonstackdb',
    password: 'node_password',
    port: 5432
}